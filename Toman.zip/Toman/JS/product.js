 // take element
 const showPopupButton = document.getElementById('show-popup'); //create constant variable name showPopupButton
 const popup = document.getElementById('category-popup');  //create constant variable name showPopupButton
 const closePopupButton = document.getElementById('close-popup');  //create constant variable name showPopupButton
 const categoryButtons = document.querySelectorAll('.category-btn');  //create constant variable name showPopupButton

 // popup display after click button
 showPopupButton.addEventListener('click', function() {  // calling function for style fron js
   popup.style.display = 'flex'; //giving style for display 
 });

 // close button after click button
 closePopupButton.addEventListener('click', function() {  // calling function for style fron js
   popup.style.display = 'none';//gives style to popup section
 });

 // catogory is handel from here
 categoryButtons.forEach(function(button) {
   button.addEventListener('click', function() {
     const targetSection = button.getAttribute('data-target'); //refers to the element in button & pull out the value from atribute from button
     const targetElement = document.querySelector(targetSection);
     if (targetElement) {
       targetElement.scrollIntoView({ behavior: 'smooth' });//target to precice element
     }
     popup.style.display = 'none'; // Close the popup after selection from here
   });
 });