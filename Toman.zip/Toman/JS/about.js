// Function to toggle the details visibility of each team member
function toggleDetails(memberId) {
    const details = document.getElementById(`details-${memberId}`);
    const isVisible = details.style.display === 'block';
    details.style.display = isVisible ? 'none' : 'block';
  }