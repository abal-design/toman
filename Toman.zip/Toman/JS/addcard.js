// DOM Elements
const accountButton = document.getElementById('account-button'); // Button to show popup
const cartPopup = document.getElementById('cart-popup'); // Cart popup
const closeCart = document.getElementById('close-cart'); // Close button

// Show Popup
accountButton.addEventListener('click', (event) => {
  event.preventDefault(); // Prevent default behavior if any
  cartPopup.style.display = 'flex'; // Show popup
});

// Close Popup
closeCart.addEventListener('click', () => {
  cartPopup.style.display = 'none'; // Hide popup
});

// Close Popup by Clicking Outside
document.addEventListener('click', (event) => {
  // Close the popup if the click is outside the popup and not on the button
  if (!cartPopup.contains(event.target) && event.target !== accountButton) {
    cartPopup.style.display = 'none';
  }
});

// Prevent Event Bubbling (for clicks inside the popup)
cartPopup.addEventListener('click', (event) => {
  event.stopPropagation(); // Stop the event from bubbling up
});
