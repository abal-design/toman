
      // Newsletter form validation
      const newsletterForm = document.getElementById('newsletterForm');
      const emailInput = document.getElementById('emailInput');
      const emailError = document.getElementById('emailError');

      function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
      }

      newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = emailInput.value.trim();

        if (!validateEmail(email)) {
          emailError.style.display = 'block';
          emailInput.focus();
          return;
        }

        emailError.style.display = 'none';
        // Here you would typically send the email to your backend
        alert('Thank you for subscribing!');
        newsletterForm.reset();
      });
