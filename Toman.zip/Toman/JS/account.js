
  // Select the login form container (first child of the `.auth-box` class).
const loginBox = document.querySelector('.auth-box:nth-child(1)');
// Select the signup form container (second child of the `.auth-box` class).
const signupBox = document.querySelector('.auth-box:nth-child(2)');
// Select the "Sign Up" link (with ID `switch-to-signup`) from the login form.
const switchToSignup = document.getElementById('switch-to-signup');
// Select the "Login" link (with ID `switch-to-login`) from the signup form.
const switchToLogin = document.getElementById('switch-to-login');

// Add a click event listener to the "Sign Up" link.
switchToSignup.addEventListener('click', (e) => {
  e.preventDefault(); // Prevent the default behavior of the link (e.g., navigating to a new page).
  // Hide the login form by adding the "hidden" class to the loginBox element.
  loginBox.classList.add('hidden');
 // Show the signup form by removing the "hidden" class from the signupBox element.
  signupBox.classList.remove('hidden'); 
});

// Add a click event listener to the "Login" link.
switchToLogin.addEventListener('click', (e) => {
  e.preventDefault(); // Prevent the default behavior of the link (e.g., navigating to a new page).
  // Hide the signup form by adding the "hidden" class to the signupBox element.
  signupBox.classList.add('hidden');
  // Show the login form by removing the "hidden" class from the loginBox element.
  loginBox.classList.remove('hidden');
});
